<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<meta name="author" content="GallerySoft.info" />
    		<link rel="stylesheet" href="style.css" type="text/css" />
		<title>	Welcome to Gấu's restaurant	</title>
	</head>
		
	<body>
		<?php
			include 'head.html';
		?>
		<?php
			include 'end.html';
		?>
			
	</body>
</html>
