<!DOCTYPE html>
<html>
	<head> 
		<?php 

		include'logo_tab.php';
		?>
		<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<meta name="author" content="GallerySoft.info" />
    		<link rel="stylesheet" href="style.css" type="text/css" />
		<title> Đặt món </title>
	</head>
	<body>
		<?php
			
			include 'head_user.html';
		?>
		
		<br><br><br>
		<?php
			include 'Menu_order.php';
		?>
		
		<?php
			include 'end.html';
		?>
	</body>
</html>