$(document).ready(function (){
$('.carousel').carousel({
interval: 1750
});
});