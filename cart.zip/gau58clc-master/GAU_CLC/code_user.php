<html>
	<head>
		<?php include"logo_tab.php" ?>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<title> Welcome to Gấu's Restaurant </title>
		<meta name="author" content="GallerySoft.info" />
    		<link rel="stylesheet" href="style.css" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/lightbox.css">
		<script type="text/javascript" src="jquery.flexisel.js"></script>
		<link href="style.css" rel="stylesheet" type="text/css" media="screen,print" />
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen,print" />
		<link href="css/bootstrap-theme.css" rel="stylesheet" type="text/css" media="screen,print" />
		<script type="text/javascript" src="js/bootstrap.js"></script>
	</head>
	<body>
		<?php
			session_start();
			include 'head_user.html';
		?>
		<style type="text/css">
        <!--
        .style2 {
	       color: #CC0000;
	       font-weight: bold;
	       font-size: 18px;
        }
        -->
        </style>
		<br><br><br><br>
		<div class = "container">
			<div class = "intro">
				<div class="style2">
					CHÚC CÁC BẠN CÓ MỘT TUẦN LÀM VIỆC HIỆU QUẢ 
				</div>
            </div>
		</div>
		
		<?php
			include 'end.html';
		?>
	</body>
</html>