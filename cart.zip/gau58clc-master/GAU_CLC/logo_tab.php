<?php
	echo '<link rel="shortcut icon" href="image\BEAR-LOGO.png"/>';
?>