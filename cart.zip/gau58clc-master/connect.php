<?php
	
	$conn = mysqli_connect("localhost","root","","restaurent");

	mysqli_query($conn,"SET NAMES 'utf8'");
?>