﻿NHÓM GẤU
﻿
Đề tài 5: Nhà hàng.

PROJECT CHÍNH ĐƯỢC ĐẶT Ở FORDER "GAU_CLC". 

Đây là 1 phần mềm quản lý nhà hàng. Cho phép khách hàng có thể tương tác với chủ quán mà không cần phải gặp mặt trực tiếp. Giúp cho việc đặt món dễ dàng, thuận tiện và không gây nhầm lẫn.

Các thành viên (5):

1. Phan Anh
2. Phạm Văn Chính 
3. Nguyễn Viết Cương (product owner)
4. Vũ Mạnh Tiến	(scrum master)
5. Ngô Thị Phượng

<<<<<<< HEAD >>>>>>>>

Ngôn ngữ sử dụng: HTML, CSS, JavaScript, PHP.

Quy trình: scrum (chính xác thì Scrum không phải là một quy trình hay một kĩ thuật cụ  thể  để xây dựng sản phẩm;nó là một khung làm việc cho phép bạn sử dụng nhiều quy trình và kĩ thuật khác nhau.)

=====================

Sprint 1: chức năng thêm món

User story: 

	1. là người khách hàng tôi muốn xem menu các món ăn của nhà hàng một cách rõ ràng
	
	2. là người quản trị tôi muốn thêm món ăn vào menu

Sprint 2: đăng nhập và đăng xuất

Link demo : https://www.youtube.com/watch?v=Hvgi66vLST8&feature=youtu.be

User story:

	1. Là người quản trị viên, tôi muốn có quyền quản lí truy cập để những người khác (người dùng, khách hàng) sẽ không có khả năng thay đổi hiển thị trang web.

	2.Là người quản trị viên, tôi muốn có quyền chỉnh sửa cơ sở dữ liệu (bài viết, hình ảnh) để thuận tiện cho việc phát triển nhà hàng.

	3. Là người quản trị, tôi muốn có quyền hạn chế truy cập với người sử dụng website.

	4. Là người quản trị, tôi muốn website đảm bảo tính bảo mật để thông tin khách hàng được bảo đảm.
	
spint 3: góp ý (phản hồi) của khách hàng

Link demo: https://www.youtube.com/watch?v=dEcfhev3jGM&feature=youtu.be

User story:

	1. Là người quản trị viên, tôi muốn nhận được những ý kiến của đánh giá của khách hàng về nhà hàng của mình

	2. Là người quản trị viên, tôi muốn những góp ý của khách hàng để vào một mục riêng

	3. Là người quản trị viên, tôi muốn bảo mật những góp ý của khách hàng và chỉ mình tôi có thể quản lý chúng

	4. Là người quản trị viên, tôi muốn biết những góp ý được gửi đến là của ai

	5. Là người khách hàng, tôi muốn phản hồi những đánh giá của mình tới chủ cửa hàng

	6. Là người khách hàng, tôi muốn đảm bảo thông tin cá nhân khi muốn phản hồi những đánh giá của mình tới chủ cửa hàng

	7. Là người khách hàng, tôi muốn phản hồi tới chủ cửa hàng nhưng ẩn danh

	8. Là người khách hàng đã góp ý cho cửa hàng, tôi muốn biết suy nghĩ của chủ cửa hàng về những góp ý đấy

Spint 4: chức năng edit món của người quản lý

.

User story:

	1. Là người quản trị viên, tôi muốn cập nhật thông tin món ăn của cửa hàng để người dùng có thông tin chính xác nhất
	2. Là người quản trị viên, tôi không muốn thông tin món ăn dễ bị thay đổi bởi khách hàng
	3. Là người khách hàng, tôi muốn mọi thông tin đến từ cửa hàng sát với thực tế nhất tránh tình trạng giá niêm yết từ tận năm ngoái
	
Sprint 5: chức năng đặt món của khách hàng và bàn ăn

.

User story:

	1. Là người quản lý, tôi muốn nhận được đơn đặt hàng của khách hàng qua mạng
	2. Là người khách hàng, tôi muốn đặt món ăn mà không cần phải chờ phục vụ đến tận nơi để hỏi
	3. Là người quản lý tôi muốn xem Hóa đơn từng bàn ăn
	4. Là người khách hàng tôi muốn xem Hóa đơn của mình
	5. Là người quản lý tôi sẽ reset lại hóa đơn của bàn khi khách hàng thanh toán tiền và ra về, để phục vụ cho khách hàng kế tiếp.


	
