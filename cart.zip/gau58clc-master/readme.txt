﻿* thông tin dự án ở file nhom_gau.txt
* readme.md dùng để hiển thị trong github
* readme.txt hướng dẫn cách chạy dự án
* dự án ở trong folder GAU_CLC
- sử dụng ngôn ngữ HTML, PHP, CSS
- dùng XAMPP để tạo localhost chạy project
download XAMPP ở đây: http://xampp.1800download.com/?c=11&gclid=CNHZvaiH4sQCFYKWvQodUSwAKQ

bước 1: bật XAMPP chạy Apache và MySQL (lưu ý đổi cổng XAMPP thành Main port: 70 và SSL port: 600 search google)
bước 2: mở file Code.php trong folder GAU_CLC
bước 3: thay đường dẫn "file:///C:/xampp/htdocs/gau58clc/GAU_CLC/Code.php"
		thành 		     "localhost/gau58clc/GAU_CLC/Code.php"
		hoặc		  "localhost:70/gau58clc/GAU_CLC/Code.php"
lý do dùng XAMPP: để chạy được đoạn mã PHP và sử dụng database
